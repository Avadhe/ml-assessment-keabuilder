import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class SimilarityEngine:
    def __init__(self):
        self.vectorizer = TfidfVectorizer()
        self.corpus = []
        self.vectors = None

    def fit(self, inputs):
        """
        Fits the engine with a list of sample inputs.
        """
        self.corpus = inputs
        self.vectors = self.vectorizer.fit_transform(self.corpus)

    def find_top_match(self, query):
        """
        Finds the most similar input from the corpus for a given query.
        """
        if self.vectors is None:
            raise ValueError("Engine must be fitted with inputs first.")
        
        query_vector = self.vectorizer.transform([query])
        similarities = cosine_similarity(query_vector, self.vectors).flatten()
        
        top_index = np.argmax(similarities)
        top_score = similarities[top_index]
        
        return {
            "match": self.corpus[top_index],
            "score": float(top_score),
            "index": int(top_index)
        }

if __name__ == "__main__":
    # Sample inputs relevant to KeaBuilder (funnels, leads, prompts)
    samples = [
        "How do I create a high-converting sales funnel?",
        "Capture more leads with our automated chatbot.",
        "Integrate your CRM with KeaBuilder for better lead management.",
        "Design a landing page that converts visitors into customers.",
        "Automate your email marketing campaigns easily."
    ]
    
    engine = SimilarityEngine()
    engine.fit(samples)
    
    # Test query
    test_query = "I want to build a funnel to get more customers"
    result = engine.find_top_match(test_query)
    
    print(f"Query: {test_query}")
    print(f"Top Match: {result['match']}")
    print(f"Similarity Score: {result['score']:.4f}")
