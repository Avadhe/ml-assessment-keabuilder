from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

app = FastAPI(title="KeaBuilder Similarity API")

class QueryRequest(BaseModel):
    query: str
    samples: List[str]

class MatchResponse(BaseModel):
    match: str
    score: float
    index: int

@app.post("/match", response_model=MatchResponse)
async def find_match(request: QueryRequest):
    if not request.samples:
        raise HTTPException(status_code=400, detail="Samples list cannot be empty")
    
    vectorizer = TfidfVectorizer()
    try:
        vectors = vectorizer.fit_transform(request.samples)
        query_vector = vectorizer.transform([request.query])
        
        similarities = cosine_similarity(query_vector, vectors).flatten()
        top_index = np.argmax(similarities)
        
        return {
            "match": request.samples[top_index],
            "score": float(similarities[top_index]),
            "index": int(top_index)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
